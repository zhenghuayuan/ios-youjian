#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import <UIKit/UIKit.h>
//#import "weixin_sdk/WXApi.h"

#import "BasicWeiXin.h"
//#import "BasicWeiXinObject.h"
//#import "Reachability.h"

//#include "json/json.h"

//#import "spay_sdk/include/SPayClient.h"
#import "include/SPayClient.h"



//implementation
@implementation CBasicWeixin

-(void)pay_weixin:(NSString* )token: (NSString*) service
{
	NSNumber* ns_amount = [NSNumber numberWithInt: 1];
    NSString* ns_token = token;
    NSString* ns_service = service;

    //NSLog(@"xxm:weixin pay ns_token:%@", ns_token);
    //NSLog(@"xxm:weixin pay ns_service:%@", ns_service);
    UIViewController* pView = [UIApplication sharedApplication].keyWindow.rootViewController;
    [[SPayClient sharedInstance] pay: pView
        amount:ns_amount
    	spayTokenIDString:ns_token
    	payServicesString:@"pay.weixin.app"
    	finish:^(SPayClientPayStateModel *payStateModel,
    	 SPayClientPaySuccessDetailModel *paySuccessDetailModel) {
    	 	//weakSelf.out_trade_noText.text = [NSString spay_out_trade_no];
    	 	if (payStateModel.payState == SPayClientConstEnumPaySuccess) {
    	 		NSLog(@"支付成功");
    	 		NSLog(@"支付订单详情-->>\n%@",[paySuccessDetailModel description]);
    	 	}else{
    	 		NSLog(@"支付失败，错误号:%d",payStateModel.payState);
    	 	}
    	}];
}

@end

