#pragma once
#ifndef __BASICWEIXIN_H__
#define __BASICWEIXIN_H__
#import <Foundation/Foundation.h>

//#include <iostream>
//#include <vector>

@interface CBasicWeixin : NSObject

+(void) pay_weixin:(NSString* )token: (NSString*) service;

@end

#endif
