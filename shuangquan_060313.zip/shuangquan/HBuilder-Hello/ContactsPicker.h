
// -------------------------------------------------------------
// 定义类NjsHello
@interface ContactsPicker : NSObject {
}
+(void)do_pick:(NSString*)name;
+(void)handler_pick_end:(NSString*)tel;
+(NSString*)get_tel;
@end
