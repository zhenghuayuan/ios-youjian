#import "ContactsPicker.h"

#import "AppDelegate.h"

#import "PDRCore.h"
#import "PDRCoreApp.h"
#import "PDRCoreAppFrame.h"
#import "PDRCoreAppManager.h"
#import "PDRCoreAppWIndow.h"

static NSString *web_name;
static NSString *tel_num;

// 实现类ContactsPicker
@implementation ContactsPicker

+(void)do_pick:(NSString*)name{
    web_name = [name copy];
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [app showContactPicker];
}
+(void)handler_pick_end:(NSString*)tel{
    tel_num = [tel copy];
    PDRCore *core = [PDRCore Instance];
    PDRCoreAppManager *app_mgr = core.appManager;
    PDRCoreApp *app = [app_mgr getMainApp];
    PDRCoreAppWindow *win = app.appWindow;
    PDRCoreAppFrame *frame = [win getFrameByName:web_name];
    [frame dispatchDocumentEvent:@"contacts_pick"];
}
+(NSString*)get_tel{
    return tel_num;
}

@end
